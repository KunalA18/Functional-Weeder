## Unreleased
- Add combinator for function/arity syntax
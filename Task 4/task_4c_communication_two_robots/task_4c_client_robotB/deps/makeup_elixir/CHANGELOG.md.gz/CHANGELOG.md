# Changelog

## 0.15.2 (2021-10-13)

* Highlight Erlang calls as modules.
* Support digits as modifiers in sigils.
* Support stepped ranges operators `..//`.

## 0.15.1 (2021-01-29)

* Multiple bug fixes and update list of tokens.

## 0.15.0 (2020-10-02)

* Added support for Unicode characters in identifiers (atoms and variables).
* Improved handling of sigils.

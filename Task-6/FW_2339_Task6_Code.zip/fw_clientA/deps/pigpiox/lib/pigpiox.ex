defmodule Pigpiox do
  @moduledoc """
  Pigpiox is an Elixir wrapper around the [pigpio daemon](http://abyz.co.uk/rpi/pigpio/index.html).
  """
end

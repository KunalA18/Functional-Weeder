defmodule FWServerWeb.PageView do
  use FWServerWeb, :view
end

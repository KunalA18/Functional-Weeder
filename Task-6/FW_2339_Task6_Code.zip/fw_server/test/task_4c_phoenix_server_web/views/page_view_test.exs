defmodule FWServerWeb.PageViewTest do
  use FWServerWeb.ConnCase, async: true
end

defmodule FWClientRobotA.Position do
  defstruct x: 1, y: :a, facing: :north
end

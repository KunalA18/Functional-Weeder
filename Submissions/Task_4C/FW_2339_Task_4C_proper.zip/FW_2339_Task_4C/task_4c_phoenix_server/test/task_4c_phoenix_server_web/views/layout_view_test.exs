defmodule Task4CPhoenixServerWeb.LayoutViewTest do
  use Task4CPhoenixServerWeb.ConnCase, async: true

  # When testing helpers, you may want to import Phoenix.HTML and
  # use functions such as safe_to_string() to convert the helper
  # result into an HTML string.
  # import Phoenix.HTML
end
